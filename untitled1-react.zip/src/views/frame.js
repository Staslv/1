import React from 'react'

import { Helmet } from 'react-helmet'

import './frame.css'

const Frame = (props) => {
  return (
    <div className="frame-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="frame-frame">
        <div className="frame-group1000004603">
          <img src alt="Vector1014" className="frame-vector" />
          <img
            src="/external/vector1015-xry.svg"
            alt="Vector1015"
            className="frame-vector001"
          />
          <img
            src="/external/vector1016-270k.svg"
            alt="Vector1016"
            className="frame-vector002"
          />
          <img
            src="/external/vector1017-0oc6.svg"
            alt="Vector1017"
            className="frame-vector003"
          />
          <img
            src="/external/vector1018-moxj.svg"
            alt="Vector1018"
            className="frame-vector004"
          />
          <img
            src="/external/vector1019-jf5c.svg"
            alt="Vector1019"
            className="frame-vector005"
          />
          <img
            src="/external/vector1011-jww.svg"
            alt="Vector1011"
            className="frame-vector006"
          />
          <img
            src="/external/vector1011-9ih.svg"
            alt="Vector1011"
            className="frame-vector007"
          />
          <img
            src="/external/vector1011-fpg6.svg"
            alt="Vector1011"
            className="frame-vector008"
          />
        </div>
        <div className="frame-frame8826">
          <span className="frame-text">
            <span>Documentation</span>
          </span>
          <span className="frame-text002">
            <span>legal information</span>
          </span>
          <span className="frame-text004">
            <span>Processing of personal data</span>
          </span>
          <span className="frame-text006">
            <span>Social responsibility</span>
          </span>
          <span className="frame-text008">
            <span>Anti-corruption policy</span>
          </span>
          <span className="frame-text010">
            <span>
              Procedure for ordering and providing services on the website
            </span>
          </span>
          <span className="frame-text012">
            <span>
              Payment rules and payment security, confidentiality of information
              and refusal of service
            </span>
          </span>
        </div>
        <img
          src="/external/image11012-9tts-1100w.png"
          alt="image11012"
          className="frame-image1"
        />
        <img
          src="/external/svg1012-v58h.svg"
          alt="SVG1012"
          className="frame-svg"
        />
        <img
          src="/external/ellipse99731013-dzp5-700w.png"
          alt="Ellipse99731013"
          className="frame-ellipse9973"
        />
        <img
          src="/external/ellipse99721013-4lp-700w.png"
          alt="Ellipse99721013"
          className="frame-ellipse9972"
        />
        <div className="frame-frame01">
          <div className="frame-group">
            <div className="frame-frame02">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector009"
              />
            </div>
          </div>
        </div>
        <div className="frame-frame03">
          <div className="frame-group001">
            <img
              src="/external/vector1014-azwq.svg"
              alt="Vector1014"
              className="frame-vector010"
            />
            <img
              src="/external/vector1014-56th.svg"
              alt="Vector1014"
              className="frame-vector011"
            />
            <img
              src="/external/vector1014-f1jg.svg"
              alt="Vector1014"
              className="frame-vector012"
            />
            <img
              src="/external/vector1014-s0go.svg"
              alt="Vector1014"
              className="frame-vector013"
            />
            <img
              src="/external/vector1014-xy5m.svg"
              alt="Vector1014"
              className="frame-vector014"
            />
            <img
              src="/external/vector1014-igh2.svg"
              alt="Vector1014"
              className="frame-vector015"
            />
          </div>
          <div className="frame-group002">
            <img
              src="/external/vector1014-ina.svg"
              alt="Vector1014"
              className="frame-vector016"
            />
            <img
              src="/external/vector1014-p7ga.svg"
              alt="Vector1014"
              className="frame-vector017"
            />
            <img
              src="/external/vector1014-tqt.svg"
              alt="Vector1014"
              className="frame-vector018"
            />
            <img
              src="/external/vector1015-k86j.svg"
              alt="Vector1015"
              className="frame-vector019"
            />
            <img
              src="/external/vector1015-p54.svg"
              alt="Vector1015"
              className="frame-vector020"
            />
            <img
              src="/external/vector1015-m9t.svg"
              alt="Vector1015"
              className="frame-vector021"
            />
          </div>
          <div className="frame-group003">
            <img
              src="/external/vector1015-cr3q.svg"
              alt="Vector1015"
              className="frame-vector022"
            />
            <img
              src="/external/vector1015-mds5.svg"
              alt="Vector1015"
              className="frame-vector023"
            />
            <img
              src="/external/vector1015-ruhs.svg"
              alt="Vector1015"
              className="frame-vector024"
            />
            <img
              src="/external/vector1015-oufm.svg"
              alt="Vector1015"
              className="frame-vector025"
            />
            <img
              src="/external/vector1015-rtzf.svg"
              alt="Vector1015"
              className="frame-vector026"
            />
            <img
              src="/external/vector1015-gnky.svg"
              alt="Vector1015"
              className="frame-vector027"
            />
          </div>
          <div className="frame-group004">
            <img
              src="/external/vector1016-5pt.svg"
              alt="Vector1016"
              className="frame-vector028"
            />
            <img
              src="/external/vector1016-o4ym.svg"
              alt="Vector1016"
              className="frame-vector029"
            />
            <img
              src="/external/vector1016-s9we.svg"
              alt="Vector1016"
              className="frame-vector030"
            />
            <img
              src="/external/vector1016-8qtq.svg"
              alt="Vector1016"
              className="frame-vector031"
            />
            <img
              src="/external/vector1016-k4yn.svg"
              alt="Vector1016"
              className="frame-vector032"
            />
            <img
              src="/external/vector1016-307.svg"
              alt="Vector1016"
              className="frame-vector033"
            />
          </div>
          <div className="frame-group005">
            <img
              src="/external/vector1016-dwg.svg"
              alt="Vector1016"
              className="frame-vector034"
            />
            <img
              src="/external/vector1016-6jy.svg"
              alt="Vector1016"
              className="frame-vector035"
            />
            <img
              src="/external/vector1017-eoo7.svg"
              alt="Vector1017"
              className="frame-vector036"
            />
            <img
              src="/external/vector1017-gl6.svg"
              alt="Vector1017"
              className="frame-vector037"
            />
            <img
              src="/external/vector1017-rvlz.svg"
              alt="Vector1017"
              className="frame-vector038"
            />
            <img
              src="/external/vector1017-t4eq.svg"
              alt="Vector1017"
              className="frame-vector039"
            />
          </div>
          <div className="frame-group006">
            <img
              src="/external/vector1017-1kvs.svg"
              alt="Vector1017"
              className="frame-vector040"
            />
            <img
              src="/external/vector1017-ji2.svg"
              alt="Vector1017"
              className="frame-vector041"
            />
            <img
              src="/external/vector1017-qsg.svg"
              alt="Vector1017"
              className="frame-vector042"
            />
            <img
              src="/external/vector1017-qb8o.svg"
              alt="Vector1017"
              className="frame-vector043"
            />
            <img
              src="/external/vector1017-u92.svg"
              alt="Vector1017"
              className="frame-vector044"
            />
            <img
              src="/external/vector1018-etha.svg"
              alt="Vector1018"
              className="frame-vector045"
            />
          </div>
        </div>
        <div className="frame-frame8793">
          <span className="frame-text014">
            <span>Corporate messenger for team organization</span>
          </span>
          <span className="frame-text016">
            <span className="frame-text017">
              A functional product for business in
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span>a clear interface</span>
          </span>
          <div className="frame-frame6">
            <span className="frame-text019">
              <span>Try for free</span>
            </span>
          </div>
        </div>
        <img src="/external/svg1018-r9a.svg" alt="SVG1018" />
        <img
          src="/external/image62283791019-4k8-800h.png"
          alt="IMAGE62283791019"
          className="frame-image6228379"
        />
        <div className="frame-group007">
          <img
            src="/external/vector1019-sfp.svg"
            alt="Vector1019"
            className="frame-vector046"
          />
          <img
            src="/external/vector1019-o3qjn.svg"
            alt="Vector1019"
            className="frame-vector047"
          />
          <div className="frame-group008">
            <img
              src="/external/vector1011-zoo.svg"
              alt="Vector1011"
              className="frame-vector048"
            />
            <img
              src="/external/vector1011-10nt.svg"
              alt="Vector1011"
              className="frame-vector049"
            />
            <img
              src="/external/vector1011-pyjr.svg"
              alt="Vector1011"
              className="frame-vector050"
            />
            <img
              src="/external/vector1011-bc8.svg"
              alt="Vector1011"
              className="frame-vector051"
            />
            <img
              src="/external/vector1011-zj56.svg"
              alt="Vector1011"
              className="frame-vector052"
            />
            <img
              src="/external/vector1011-h2j.svg"
              alt="Vector1011"
              className="frame-vector053"
            />
            <img
              src="/external/vector1011-zzrd.svg"
              alt="Vector1011"
              className="frame-vector054"
            />
            <img
              src="/external/vector1011-d0ht.svg"
              alt="Vector1011"
              className="frame-vector055"
            />
            <img
              src="/external/vector1011-kgno.svg"
              alt="Vector1011"
              className="frame-vector056"
            />
            <img
              src="/external/vector1011-6288.svg"
              alt="Vector1011"
              className="frame-vector057"
            />
            <img
              src="/external/vector1011-90so.svg"
              alt="Vector1011"
              className="frame-vector058"
            />
            <img
              src="/external/vector1011-qyrg.svg"
              alt="Vector1011"
              className="frame-vector059"
            />
            <img
              src="/external/vector1011-n2yp.svg"
              alt="Vector1011"
              className="frame-vector060"
            />
            <img
              src="/external/vector1011-mclc.svg"
              alt="Vector1011"
              className="frame-vector061"
            />
            <img
              src="/external/vector1011-o52.svg"
              alt="Vector1011"
              className="frame-vector062"
            />
            <img
              src="/external/vector1011-8jm.svg"
              alt="Vector1011"
              className="frame-vector063"
            />
            <img
              src="/external/vector1011-4n7a.svg"
              alt="Vector1011"
              className="frame-vector064"
            />
            <img
              src="/external/vector1011-0aee.svg"
              alt="Vector1011"
              className="frame-vector065"
            />
          </div>
        </div>
        <img
          src="/external/rectangle346241191011-9ttp-1600w.png"
          alt="Rectangle346241191011"
          className="frame-rectangle34624119"
        />
        <img
          src="/external/rectangle346241291011-h8hu-1600w.png"
          alt="Rectangle346241291011"
          className="frame-rectangle34624129"
        />
        <div className="frame-group1000004600">
          <img src alt="Vector1011" className="frame-vector066" />
          <img
            src="/external/vector1011-jnfw.svg"
            alt="Vector1011"
            className="frame-vector067"
          />
          <img
            src="/external/vector1011-jox.svg"
            alt="Vector1011"
            className="frame-vector068"
          />
          <img
            src="/external/vector1011-sb84.svg"
            alt="Vector1011"
            className="frame-vector069"
          />
          <img
            src="/external/vector1011-nzql.svg"
            alt="Vector1011"
            className="frame-vector070"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1011"
            className="frame-vector071"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1011"
            className="frame-vector072"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1011"
            className="frame-vector073"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1011"
            className="frame-vector074"
          />
        </div>
        <img
          src="/external/ellipse99801011-cig-800w.png"
          alt="Ellipse99801011"
          className="frame-ellipse9980"
        />
        <div className="frame-group1000004598">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="SVG11011"
            className="frame-svg1 frame-svg1"
          />
        </div>
        <div className="frame-group1000004604">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="SVG11011"
            className="frame-svg11"
          />
        </div>
        <div className="frame-frame8790">
          <span className="frame-text021">
            <span>Решения</span>
          </span>
          <span className="frame-text023">
            <span>Безопасность</span>
          </span>
          <span className="frame-text025">
            <span>Интеграции</span>
          </span>
          <span className="frame-text027">
            <span>Цены</span>
          </span>
          <span className="frame-text029">
            <span>О нас</span>
          </span>
        </div>
        <div className="frame-frame2">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="materialsymbolslightdownload1011"
            className="frame-materialsymbolslightdownload"
          />
          <span className="frame-text031">
            <span>Скачать</span>
          </span>
        </div>
        <div className="frame-frame8792">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Rectangle1011"
            className="frame-rectangle"
          />
          <div className="frame-frame8791">
            <span className="frame-text033">
              <span>ru</span>
            </span>
            <img
              src="/external/vector1011-56sa.svg"
              alt="Vector1011"
              className="frame-vector075"
            />
          </div>
        </div>
        <div className="frame-frame2813">
          <div className="frame-group1000004488">
            <div className="frame-group1000004495">
              <span className="frame-text035">
                <span>More than just chats</span>
              </span>
              <span className="frame-text037">
                <span>
                  An advanced system for organizing corporate communications,
                  from video calls to task setting
                </span>
              </span>
            </div>
          </div>
          <span className="frame-text039">
            <span>01</span>
          </span>
        </div>
        <div className="frame-frame8806">
          <div className="frame-group10000044881">
            <div className="frame-group10000044951">
              <span className="frame-text041">
                <span>Installation on company servers</span>
              </span>
              <span className="frame-text043">
                <span>
                  Im&apos;work can be hosted either on-premise on your servers
                  or in a private cloud
                </span>
              </span>
            </div>
          </div>
          <div className="frame-freeiconserver900334">
            <div className="frame-group009">
              <div className="frame-group010">
                <img
                  src="/external/vector1011-6t6p.svg"
                  alt="Vector1011"
                  className="frame-vector076"
                />
              </div>
            </div>
            <div className="frame-group011">
              <div className="frame-group012">
                <img
                  src="/external/vector1011-yv5s.svg"
                  alt="Vector1011"
                  className="frame-vector077"
                />
              </div>
            </div>
            <div className="frame-group013">
              <div className="frame-group014">
                <img
                  src="/external/vector1011-0uk.svg"
                  alt="Vector1011"
                  className="frame-vector078"
                />
              </div>
            </div>
            <div className="frame-group015">
              <div className="frame-group016">
                <img
                  src="/external/vector1011-kmooj.svg"
                  alt="Vector1011"
                  className="frame-vector079"
                />
              </div>
            </div>
            <div className="frame-group017">
              <div className="frame-group018">
                <img
                  src="/external/vector1011-ucnk.svg"
                  alt="Vector1011"
                  className="frame-vector080"
                />
              </div>
            </div>
            <div className="frame-group019">
              <div className="frame-group020">
                <img
                  src="/external/vector1011-ixth.svg"
                  alt="Vector1011"
                  className="frame-vector081"
                />
              </div>
            </div>
            <div className="frame-group021">
              <div className="frame-group022">
                <img
                  src="/external/vector1011-kp7.svg"
                  alt="Vector1011"
                  className="frame-vector082"
                />
              </div>
            </div>
            <div className="frame-group023">
              <div className="frame-group024">
                <img
                  src="/external/vector1012-v9to.svg"
                  alt="Vector1012"
                  className="frame-vector083"
                />
              </div>
            </div>
            <div className="frame-group025">
              <div className="frame-group026">
                <img
                  src="/external/vector1012-p4n.svg"
                  alt="Vector1012"
                  className="frame-vector084"
                />
              </div>
            </div>
            <div className="frame-group027">
              <div className="frame-group028">
                <img
                  src="/external/vector1012-lw65.svg"
                  alt="Vector1012"
                  className="frame-vector085"
                />
              </div>
            </div>
            <div className="frame-group029">
              <div className="frame-group030">
                <img
                  src="/external/vector1012-32rf.svg"
                  alt="Vector1012"
                  className="frame-vector086"
                />
              </div>
            </div>
            <div className="frame-group031">
              <div className="frame-group032">
                <img
                  src="/external/vector1012-27hu.svg"
                  alt="Vector1012"
                  className="frame-vector087"
                />
              </div>
            </div>
            <div className="frame-group033">
              <div className="frame-group034">
                <img
                  src="/external/vector1012-u1df.svg"
                  alt="Vector1012"
                  className="frame-vector088"
                />
              </div>
            </div>
            <div className="frame-group035">
              <div className="frame-group036">
                <img
                  src="/external/vector1012-kxzx.svg"
                  alt="Vector1012"
                  className="frame-vector089"
                />
              </div>
            </div>
            <div className="frame-group037">
              <div className="frame-group038">
                <img
                  src="/external/vector1012-dwlu.svg"
                  alt="Vector1012"
                  className="frame-vector090"
                />
              </div>
            </div>
            <div className="frame-group039">
              <div className="frame-group040">
                <img
                  src="/external/vector1012-ontc.svg"
                  alt="Vector1012"
                  className="frame-vector091"
                />
              </div>
            </div>
            <div className="frame-group041">
              <div className="frame-group042">
                <img
                  src="/external/vector1012-xqkk.svg"
                  alt="Vector1012"
                  className="frame-vector092"
                />
              </div>
            </div>
            <div className="frame-group043">
              <div className="frame-group044">
                <img
                  src="/external/vector1012-ygz.svg"
                  alt="Vector1012"
                  className="frame-vector093"
                />
              </div>
            </div>
            <div className="frame-group045">
              <div className="frame-group046">
                <img
                  src="/external/vector1012-83v.svg"
                  alt="Vector1012"
                  className="frame-vector094"
                />
              </div>
            </div>
            <div className="frame-group047">
              <div className="frame-group048">
                <img
                  src="/external/vector1012-012p.svg"
                  alt="Vector1012"
                  className="frame-vector095"
                />
              </div>
            </div>
            <div className="frame-group049">
              <div className="frame-group050">
                <img
                  src="/external/vector1012-6lmp.svg"
                  alt="Vector1012"
                  className="frame-vector096"
                />
              </div>
            </div>
            <div className="frame-group051">
              <div className="frame-group052">
                <img
                  src="/external/vector1012-55s.svg"
                  alt="Vector1012"
                  className="frame-vector097"
                />
              </div>
            </div>
            <div className="frame-group053">
              <div className="frame-group054">
                <img
                  src="/external/vector1012-w4zf.svg"
                  alt="Vector1012"
                  className="frame-vector098"
                />
              </div>
            </div>
            <div className="frame-group055">
              <div className="frame-group056">
                <img
                  src="/external/vector1012-81r.svg"
                  alt="Vector1012"
                  className="frame-vector099"
                />
              </div>
            </div>
            <div className="frame-group057">
              <div className="frame-group058">
                <img
                  src="/external/vector1012-t5gs.svg"
                  alt="Vector1012"
                  className="frame-vector100"
                />
              </div>
            </div>
            <div className="frame-group059">
              <div className="frame-group060">
                <img
                  src="/external/vector1012-rmv.svg"
                  alt="Vector1012"
                  className="frame-vector101"
                />
              </div>
            </div>
            <div className="frame-group061">
              <div className="frame-group062">
                <img
                  src="/external/vector1012-2e15.svg"
                  alt="Vector1012"
                  className="frame-vector102"
                />
              </div>
            </div>
            <div className="frame-group063">
              <div className="frame-group064">
                <img
                  src="/external/vector1012-6tdk.svg"
                  alt="Vector1012"
                  className="frame-vector103"
                />
              </div>
            </div>
            <div className="frame-group065">
              <div className="frame-group066">
                <img
                  src="/external/vector1012-0lz.svg"
                  alt="Vector1012"
                  className="frame-vector104"
                />
              </div>
            </div>
            <div className="frame-group067">
              <div className="frame-group068">
                <img
                  src="/external/vector1012-hn3b.svg"
                  alt="Vector1012"
                  className="frame-vector105"
                />
              </div>
            </div>
            <div className="frame-group069">
              <div className="frame-group070">
                <img
                  src="/external/vector1012-5eff.svg"
                  alt="Vector1012"
                  className="frame-vector106"
                />
              </div>
            </div>
            <div className="frame-group071">
              <div className="frame-group072">
                <img
                  src="/external/vector1012-8iy.svg"
                  alt="Vector1012"
                  className="frame-vector107"
                />
              </div>
            </div>
            <div className="frame-group073">
              <div className="frame-group074">
                <img
                  src="/external/vector1012-i8k.svg"
                  alt="Vector1012"
                  className="frame-vector108"
                />
              </div>
            </div>
            <div className="frame-group075">
              <div className="frame-group076">
                <img
                  src="/external/vector1012-fm1b.svg"
                  alt="Vector1012"
                  className="frame-vector109"
                />
              </div>
            </div>
            <div className="frame-group077">
              <div className="frame-group078">
                <img
                  src="/external/vector1012-1zie.svg"
                  alt="Vector1012"
                  className="frame-vector110"
                />
              </div>
            </div>
            <div className="frame-group079">
              <div className="frame-group080">
                <img
                  src="/external/vector1012-oj1bt.svg"
                  alt="Vector1012"
                  className="frame-vector111"
                />
              </div>
            </div>
            <div className="frame-group081">
              <div className="frame-group082">
                <img
                  src="/external/vector1012-zpk.svg"
                  alt="Vector1012"
                  className="frame-vector112"
                />
              </div>
            </div>
            <div className="frame-group083">
              <div className="frame-group084">
                <img
                  src="/external/vector1012-h35c.svg"
                  alt="Vector1012"
                  className="frame-vector113"
                />
              </div>
            </div>
            <div className="frame-group085">
              <div className="frame-group086">
                <img
                  src="/external/vector1012-53kb.svg"
                  alt="Vector1012"
                  className="frame-vector114"
                />
              </div>
            </div>
            <div className="frame-group087">
              <div className="frame-group088">
                <img
                  src="/external/vector1012-1hv.svg"
                  alt="Vector1012"
                  className="frame-vector115"
                />
              </div>
            </div>
            <div className="frame-group089">
              <div className="frame-group090">
                <img
                  src="/external/vector1013-j9fw.svg"
                  alt="Vector1013"
                  className="frame-vector116"
                />
              </div>
            </div>
            <div className="frame-group091">
              <div className="frame-group092">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector117"
                />
              </div>
            </div>
            <div className="frame-group093">
              <div className="frame-group094">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector118"
                />
              </div>
            </div>
            <div className="frame-group095">
              <div className="frame-group096">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector119"
                />
              </div>
            </div>
            <div className="frame-group097">
              <div className="frame-group098">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector120"
                />
              </div>
            </div>
            <div className="frame-group099">
              <div className="frame-group100">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector121"
                />
              </div>
            </div>
            <div className="frame-group101">
              <div className="frame-group102">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector122"
                />
              </div>
            </div>
            <div className="frame-group103">
              <div className="frame-group104">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector123"
                />
              </div>
            </div>
            <div className="frame-group105">
              <div className="frame-group106">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1013"
                  className="frame-vector124"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="frame-frame8794">
          <div className="frame-group10000044882">
            <div className="frame-group10000044952">
              <span className="frame-text045">
                <span>
                  <span>
                    Customize and
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                  <br></br>
                  <span>connect chat bots</span>
                </span>
              </span>
              <span className="frame-text050">
                <span>
                  You can adapt Im&apos;work to your needs and connect any
                  integrations
                </span>
              </span>
            </div>
          </div>
          <span className="frame-text052">
            <span>02</span>
          </span>
        </div>
        <div className="frame-frame8807">
          <div className="frame-group10000044883">
            <div className="frame-group10000044953">
              <span className="frame-text054">
                <span>
                  <span>
                    Installation
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                  <br></br>
                  <span>on company servers</span>
                </span>
              </span>
              <span className="frame-text059">
                <span>
                  Change the look of Im&apos;work to suit your corporate style
                </span>
              </span>
            </div>
          </div>
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="freeicondesign19983921013"
            className="frame-freeicondesign1998392"
          />
        </div>
        <div className="frame-frame8795">
          <div className="frame-group10000044884">
            <div className="frame-group10000044954">
              <span className="frame-text061">
                <span>Complete security communication</span>
              </span>
              <span className="frame-text063">
                <span>
                  Encryption of data transmission and the ability to integrate
                  with corporate security systems
                </span>
              </span>
            </div>
          </div>
          <span className="frame-text065">
            <span>03</span>
          </span>
        </div>
        <div className="frame-frame8808">
          <div className="frame-group10000044885">
            <div className="frame-group10000044955">
              <span className="frame-text067">
                <span>
                  <span>
                    Integration with
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                  <br></br>
                  <span>business services</span>
                </span>
              </span>
              <span className="frame-text072">
                <span>
                  Create a unified corporate environment through the interaction
                  of different services on one platform
                </span>
              </span>
            </div>
          </div>
          <div className="frame-freeiconintegration3212108">
            <div className="frame-group107">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector125"
              />
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector126"
              />
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector127"
              />
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector128"
              />
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector129"
              />
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1013"
                className="frame-vector130"
              />
            </div>
          </div>
        </div>
        <img
          src="/external/realisticfloatingsmartphonemockup0001013-oe9f-1200w.png"
          alt="realisticfloatingsmartphonemockup0001013"
          className="frame-realisticfloatingsmartphonemockup000"
        />
        <img
          src="/external/rectangle346241201013-wm6j-500h.png"
          alt="Rectangle346241201013"
          className="frame-rectangle34624120"
        />
        <span className="frame-text074">
          <span>Messenger</span>
        </span>
        <span className="frame-text076">
          <span>
            Create group and private chats, unite corporate departments and
            share files in one application
          </span>
        </span>
        <img
          src="/external/rectangle346241211013-9onb-200h.png"
          alt="Rectangle346241211013"
          className="frame-rectangle34624121"
        />
        <img
          src="/external/rectangle346241221013-21mh-200h.png"
          alt="Rectangle346241221013"
          className="frame-rectangle34624122"
        />
        <img
          src="/external/rectangle346241231013-bldo-200h.png"
          alt="Rectangle346241231013"
          className="frame-rectangle34624123"
        />
        <img
          src="/external/rectangle346241241013-tvio-200h.png"
          alt="Rectangle346241241013"
          className="frame-rectangle34624124"
        />
        <div className="frame-freeiconapi1030931">
          <div className="frame-group108">
            <img
              src="/external/vector1013-4a7.svg"
              alt="Vector1013"
              className="frame-vector131"
            />
            <img
              src="/external/vector1013-7894.svg"
              alt="Vector1013"
              className="frame-vector132"
            />
            <img
              src="/external/vector1013-qmys.svg"
              alt="Vector1013"
              className="frame-vector133"
            />
            <img
              src="/external/vector1013-j4z.svg"
              alt="Vector1013"
              className="frame-vector134"
            />
            <img
              src="/external/vector1013-fibr.svg"
              alt="Vector1013"
              className="frame-vector135"
            />
            <img
              src="/external/vector1013-p3ki.svg"
              alt="Vector1013"
              className="frame-vector136"
            />
            <img
              src="/external/vector1013-8ivr.svg"
              alt="Vector1013"
              className="frame-vector137"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1013"
              className="frame-vector138"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1013"
              className="frame-vector139"
            />
          </div>
        </div>
        <img
          src="/external/rectangle346241251013-atlz-200h.png"
          alt="Rectangle346241251013"
          className="frame-rectangle34624125"
        />
        <div className="frame-g1746">
          <div className="frame-g1748">
            <div className="frame-clippathgroup">
              <div className="frame-clip-path1754">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="path17521013"
                  className="frame-path1752"
                />
              </div>
              <div className="frame-g1750">
                <div className="frame-g1756">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="path17581013"
                    className="frame-path1758"
                  />
                </div>
                <div className="frame-g1760">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="path17621013"
                    className="frame-path1762"
                  />
                </div>
                <div className="frame-g1764">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="path17661013"
                    className="frame-path1766"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-freeicontask850340">
          <div className="frame-group109">
            <div className="frame-group110">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector140"
              />
            </div>
          </div>
          <div className="frame-group111">
            <div className="frame-group112">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector141"
              />
            </div>
          </div>
          <div className="frame-group113">
            <div className="frame-group114">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector142"
              />
            </div>
          </div>
          <div className="frame-group115">
            <div className="frame-group116">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector143"
              />
            </div>
          </div>
          <div className="frame-group117">
            <div className="frame-group118">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector144"
              />
            </div>
          </div>
          <div className="frame-group119">
            <div className="frame-group120">
              <img
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                alt="Vector1014"
                className="frame-vector145"
              />
            </div>
          </div>
          <div className="frame-group121">
            <div className="frame-group122">
              <img
                src="/external/vector1014-los.svg"
                alt="Vector1014"
                className="frame-vector146"
              />
            </div>
          </div>
          <div className="frame-group123">
            <div className="frame-group124">
              <img
                src="/external/vector1014-9ux.svg"
                alt="Vector1014"
                className="frame-vector147"
              />
            </div>
          </div>
          <div className="frame-group125">
            <div className="frame-group126">
              <img
                src="/external/vector1014-s4s3.svg"
                alt="Vector1014"
                className="frame-vector148"
              />
            </div>
          </div>
        </div>
        <div className="frame-freeiconchat1348081">
          <div className="frame-group127">
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1014"
              className="frame-vector149"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1014"
              className="frame-vector150"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1014"
              className="frame-vector151"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1014"
              className="frame-vector152"
            />
          </div>
        </div>
        <img
          src="/external/rectangle346241261014-55zl-200h.png"
          alt="Rectangle346241261014"
          className="frame-rectangle34624126"
        />
        <div className="frame-frame8796">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="materialsymbolslightdownload1014"
            className="frame-materialsymbolslightdownload1"
          />
          <span className="frame-text078">
            <span>Скачать</span>
          </span>
        </div>
        <img
          src="/external/ellipse99741014-isn-200h.png"
          alt="Ellipse99741014"
          className="frame-ellipse9974"
        />
        <img
          src="/external/ellipse99751014-mpjam-200h.png"
          alt="Ellipse99751014"
          className="frame-ellipse9975"
        />
        <img
          src="/external/ellipse99761014-9a9m-200h.png"
          alt="Ellipse99761014"
          className="frame-ellipse9976"
        />
        <img
          src="/external/ellipse99771014-ts2k-200h.png"
          alt="Ellipse99771014"
          className="frame-ellipse9977"
        />
        <span className="frame-text080">
          <span>
            Create group and private
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
        </span>
        <img
          src="/external/ellipse99781014-5dhd-500w.png"
          alt="Ellipse99781014"
          className="frame-ellipse9978"
        />
        <img
          src="/external/ellipse99791014-0u3g-600w.png"
          alt="Ellipse99791014"
          className="frame-ellipse9979"
        />
        <span className="frame-text082">
          <span>
            <span>
              Data
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span>protection</span>
          </span>
        </span>
        <span className="frame-text087">
          <span>solutions</span>
        </span>
        <span className="frame-text089">
          <span className="frame-text090">
            A functional product for business in
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
          <span>a clear interface</span>
        </span>
        <span className="frame-text092">
          <span className="frame-text093">
            A functional product for business in
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
          <span>a clear interface</span>
        </span>
        <div className="frame-group1000004601">
          <img src alt="Vector1014" className="frame-vector153" />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector154"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector155"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector156"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector157"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector158"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector159"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector160"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1014"
            className="frame-vector161"
          />
        </div>
        <img
          src="/external/rectangle346241271014-prl7-500h.png"
          alt="Rectangle346241271014"
          className="frame-rectangle34624127"
        />
        <span className="frame-text095">
          <span>International safety standards</span>
        </span>
        <span className="frame-text097">
          <span>
            Integrated interaction between Im&apos;work and information security
            systems
          </span>
        </span>
        <div className="frame-frame8797">
          <span className="frame-text099">
            <span>Active Directory/LDAP integration</span>
          </span>
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Line81014"
            className="frame-line8"
          />
          <span className="frame-text101">
            <span>Preventing DLP Leaks</span>
          </span>
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Line91014"
            className="frame-line9"
          />
          <span className="frame-text103">
            <span>Integration with your antivirus software</span>
          </span>
          <img
            src="/external/line101014-237.svg"
            alt="Line101014"
            className="frame-line10"
          />
          <span className="frame-text105">
            <span>SIEM Threat Identification</span>
          </span>
          <img
            src="/external/line111014-bs9k.svg"
            alt="Line111014"
            className="frame-line11"
          />
          <span className="frame-text107">
            <span>Encryption using TLS and DTLS protocols</span>
          </span>
        </div>
        <img
          src="/external/rectangle346241281014-ln7a-500h.png"
          alt="Rectangle346241281014"
          className="frame-rectangle34624128"
        />
        <img
          src="/external/freeicondatabasefile42333361014-likr.svg"
          alt="freeicondatabasefile42333361014"
          className="frame-freeicondatabasefile4233336"
        />
        <img
          src="/external/freeiconshield13205211014-szln.svg"
          alt="freeiconshield13205211014"
          className="frame-freeiconshield1320521"
        />
        <span className="frame-text109">
          <span>Full data control</span>
        </span>
        <span className="frame-text111">
          <span>Im&apos;work may be on</span>
        </span>
        <div className="frame-frame8798">
          <span className="frame-text113">
            <span>Your company&apos;s servers</span>
          </span>
          <img
            src="/external/line81014-tf1m.svg"
            alt="Line81014"
            className="frame-line81"
          />
          <span className="frame-text115">
            <span>
              In a private cloud on the servers of a third-party provider
            </span>
          </span>
        </div>
        <div className="frame-frame61">
          <span className="frame-text117">
            <span>To learn more</span>
          </span>
        </div>
        <div className="frame-group1000004599">
          <img
            src="/external/vector1014-qlah.svg"
            alt="Vector1014"
            className="frame-vector162"
          />
          <img
            src="/external/vector1014-hrts.svg"
            alt="Vector1014"
            className="frame-vector163"
          />
          <img
            src="/external/vector1014-p9bn.svg"
            alt="Vector1014"
            className="frame-vector164"
          />
          <img
            src="/external/vector1014-gmwo.svg"
            alt="Vector1014"
            className="frame-vector165"
          />
          <img
            src="/external/vector1014-49k5.svg"
            alt="Vector1014"
            className="frame-vector166"
          />
          <img
            src="/external/vector1014-9rd.svg"
            alt="Vector1014"
            className="frame-vector167"
          />
          <img
            src="/external/vector1014-35fd.svg"
            alt="Vector1014"
            className="frame-vector168"
          />
          <img
            src="/external/vector1014-8pms.svg"
            alt="Vector1014"
            className="frame-vector169"
          />
          <img
            src="/external/vector1014-zjw.svg"
            alt="Vector1014"
            className="frame-vector170"
          />
          <img
            src="/external/vector1014-lzln.svg"
            alt="Vector1014"
            className="frame-vector171"
          />
          <img
            src="/external/vector1014-3p6n.svg"
            alt="Vector1014"
            className="frame-vector172"
          />
          <img
            src="/external/vector1015-a8n8.svg"
            alt="Vector1015"
            className="frame-vector173"
          />
          <img
            src="/external/vector1015-1pn.svg"
            alt="Vector1015"
            className="frame-vector174"
          />
          <img
            src="/external/vector1015-teis.svg"
            alt="Vector1015"
            className="frame-vector175"
          />
          <img
            src="/external/vector1015-4y5e.svg"
            alt="Vector1015"
            className="frame-vector176"
          />
          <img
            src="/external/vector1015-c5it.svg"
            alt="Vector1015"
            className="frame-vector177"
          />
          <img
            src="/external/vector1015-7uc.svg"
            alt="Vector1015"
            className="frame-vector178"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector179"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector180"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector181"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector182"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector183"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector184"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector185"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector186"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector187"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector188"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector189"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector190"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector191"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector192"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector193"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector194"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector195"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector196"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector197"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector198"
          />
          <img
            src="/external/vector1015-ljga.svg"
            alt="Vector1015"
            className="frame-vector199"
          />
          <img
            src="/external/vector1015-9g97.svg"
            alt="Vector1015"
            className="frame-vector200"
          />
          <img
            src="/external/vector1015-9f9c.svg"
            alt="Vector1015"
            className="frame-vector201"
          />
          <img
            src="/external/vector1015-7t5p.svg"
            alt="Vector1015"
            className="frame-vector202"
          />
          <img
            src="/external/vector1015-sgvd.svg"
            alt="Vector1015"
            className="frame-vector203"
          />
          <img
            src="/external/vector1015-zlcq.svg"
            alt="Vector1015"
            className="frame-vector204"
          />
          <img
            src="/external/vector1015-yct.svg"
            alt="Vector1015"
            className="frame-vector205"
          />
          <img
            src="/external/vector1015-ljkc.svg"
            alt="Vector1015"
            className="frame-vector206"
          />
          <img
            src="/external/vector1015-dzkr.svg"
            alt="Vector1015"
            className="frame-vector207"
          />
          <img
            src="/external/vector1015-218.svg"
            alt="Vector1015"
            className="frame-vector208"
          />
          <img
            src="/external/vector1015-xdz4.svg"
            alt="Vector1015"
            className="frame-vector209"
          />
          <img
            src="/external/vector1015-vxb9.svg"
            alt="Vector1015"
            className="frame-vector210"
          />
          <img
            src="/external/vector1015-krz7.svg"
            alt="Vector1015"
            className="frame-vector211"
          />
          <img
            src="/external/vector1015-grm.svg"
            alt="Vector1015"
            className="frame-vector212"
          />
          <img
            src="/external/vector1015-l8p.svg"
            alt="Vector1015"
            className="frame-vector213"
          />
          <img
            src="/external/vector1015-zpdh.svg"
            alt="Vector1015"
            className="frame-vector214"
          />
          <img
            src="/external/vector1015-e6mi.svg"
            alt="Vector1015"
            className="frame-vector215"
          />
          <img
            src="/external/vector1015-72ao.svg"
            alt="Vector1015"
            className="frame-vector216"
          />
          <img
            src="/external/vector1015-zx8.svg"
            alt="Vector1015"
            className="frame-vector217"
          />
          <img
            src="/external/vector1015-9mn.svg"
            alt="Vector1015"
            className="frame-vector218"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector219"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector220"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector221"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector222"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector223"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector224"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector225"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector226"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector227"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector228"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector229"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector230"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector231"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector232"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector233"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector234"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector235"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector236"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector237"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector238"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector239"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector240"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector241"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector242"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector243"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1015"
            className="frame-vector244"
          />
          <div className="frame-group128">
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector245"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector246"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector247"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector248"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector249"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector250"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector251"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector252"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector253"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector254"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector255"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector256"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector257"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector258"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector259"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector260"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector261"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector262"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector263"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector264"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector265"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector266"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector267"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector268"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector269"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector270"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1015"
              className="frame-vector271"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector272"
            />
          </div>
          <div className="frame-group129">
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector273"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector274"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector275"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector276"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector277"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1016"
              className="frame-vector278"
            />
            <img
              src="/external/vector1016-ypmc.svg"
              alt="Vector1016"
              className="frame-vector279"
            />
            <img
              src="/external/vector1016-pdit.svg"
              alt="Vector1016"
              className="frame-vector280"
            />
            <img
              src="/external/vector1016-s63d.svg"
              alt="Vector1016"
              className="frame-vector281"
            />
            <img
              src="/external/vector1016-gtgn.svg"
              alt="Vector1016"
              className="frame-vector282"
            />
            <img
              src="/external/vector1016-2k7a.svg"
              alt="Vector1016"
              className="frame-vector283"
            />
            <img
              src="/external/vector1016-9mll.svg"
              alt="Vector1016"
              className="frame-vector284"
            />
            <img
              src="/external/vector1016-gpq2.svg"
              alt="Vector1016"
              className="frame-vector285"
            />
            <img
              src="/external/vector1016-9rga.svg"
              alt="Vector1016"
              className="frame-vector286"
            />
            <img
              src="/external/vector1016-6v5.svg"
              alt="Vector1016"
              className="frame-vector287"
            />
            <img
              src="/external/vector1016-ir6h.svg"
              alt="Vector1016"
              className="frame-vector288"
            />
            <img
              src="/external/vector1016-6gw5.svg"
              alt="Vector1016"
              className="frame-vector289"
            />
            <img
              src="/external/vector1016-7ika.svg"
              alt="Vector1016"
              className="frame-vector290"
            />
          </div>
          <div className="frame-group130">
            <div className="frame-group131">
              <img
                src="/external/vector1016-msh.svg"
                alt="Vector1016"
                className="frame-vector291"
              />
              <img
                src="/external/vector1016-hg7b.svg"
                alt="Vector1016"
                className="frame-vector292"
              />
              <img
                src="/external/vector1016-ghag.svg"
                alt="Vector1016"
                className="frame-vector293"
              />
            </div>
          </div>
        </div>
        <div className="frame-frame8805">
          <div className="frame-frame8803">
            <div className="frame-freeiconbriefcase2667414">
              <div className="frame-xmlid3843">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="XMLID71016"
                  className="frame-xmlid7"
                />
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="XMLID61016"
                  className="frame-xmlid6"
                />
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="XMLID51016"
                  className="frame-xmlid5"
                />
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="XMLID21016"
                  className="frame-xmlid2"
                />
              </div>
            </div>
            <div className="frame-frame8801">
              <span className="frame-text119">
                <span>For commercial organizations</span>
              </span>
              <span className="frame-text121">
                <span>
                  Work efficiently in one application using integration of
                  third-party enterprise systems
                </span>
              </span>
            </div>
          </div>
          <div className="frame-frame8802">
            <div className="frame-freeiconlaptop4439476">
              <div className="frame-group132">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1016"
                  className="frame-vector294"
                />
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1016"
                  className="frame-vector295"
                />
              </div>
            </div>
            <div className="frame-frame8800">
              <span className="frame-text123">
                <span>State organizations</span>
              </span>
              <span className="frame-text125">
                <span>
                  The messenger is included in the Register of Russian Software
                  and is being developed in accordance with the requirements of
                  Import Substitution
                </span>
              </span>
            </div>
          </div>
          <div className="frame-frame8804">
            <div className="frame-freeiconbusinessman9984441">
              <div className="frame-group133">
                <div className="frame-group134">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1016"
                    className="frame-vector296"
                  />
                </div>
              </div>
            </div>
            <div className="frame-frame8799">
              <span className="frame-text127">
                <span>For remote work</span>
              </span>
              <span className="frame-text129">
                <span>
                  To unite a team in different parts of the world - convenient,
                  simple and fast communication
                </span>
              </span>
            </div>
          </div>
        </div>
        <span className="frame-text131">
          <span>
            The development company LLC &quot;GAB TECHNOLOGIES&quot; is in the
            register of accredited organizations operating in the field of
            information technology in the Russian Federation (No. 22497 dated
            March 18, 2022)
          </span>
        </span>
        <img
          src="/external/phone14cam0111016-bvem-1100w.png"
          alt="phone14cam0111016"
          className="frame-phone14cam011"
        />
        <div className="frame-group1000004602">
          <span className="frame-text133">
            <span>Im&apos;work will help you become more productive</span>
          </span>
          <span className="frame-text135">
            <span>
              Discussion of projects, setting tasks and integration with
              business applications - all the necessary tools are combined into
              a convenient platform
            </span>
          </span>
          <div className="frame-frame88081">
            <img
              src="/external/rectangle346241301016-akl-300h.png"
              alt="Rectangle346241301016"
              className="frame-rectangle34624130"
            />
            <div className="frame-frame88071">
              <span className="frame-text137">
                <span>Onboarding</span>
              </span>
              <span className="frame-text139">
                <span>
                  Introduce employees into the workflow in just a couple of
                  clicks
                </span>
              </span>
              <div className="frame-frame88061">
                <span className="frame-text141">
                  <span>
                    Create “default” channels that all new users in your team
                    will automatically join - place instructions there, rules of
                    life in the company and tips
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame-frame8819">
            <img
              src="/external/rectangle346241321016-3l8t-300h.png"
              alt="Rectangle346241321016"
              className="frame-rectangle34624132"
            />
            <div className="frame-frame8818">
              <span className="frame-text143">
                <span>Open API</span>
              </span>
              <span className="frame-text145">
                <span>
                  Implement your own chatbot that will optimize routine
                  operations and free up time for more complex and important
                  tasks
                </span>
              </span>
              <div className="frame-frame8817">
                <span className="frame-text147">
                  <span>
                    Bots in Imwork can not only communicate in chats, but also
                    manage channels in the team and the task tracker - create
                    tasks, comment on them and change the status
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame-frame8816">
            <img
              src="/external/rectangle346241311016-kwfw-300h.png"
              alt="Rectangle346241311016"
              className="frame-rectangle34624131"
            />
            <div className="frame-frame8815">
              <span className="frame-text149">
                <span>Create your own messenger</span>
              </span>
              <span className="frame-text151">
                <span>
                  New communication environment based on Im&apos;work - with
                  your corporate identity and authorization through a corporate
                  account
                </span>
              </span>
              <div className="frame-frame8814">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Rectangle1016"
                  className="frame-rectangle01"
                />
                <div className="frame-frame8813">
                  <span className="frame-text153">
                    <span>
                      As well as three accommodation options, each of which
                      covers individual needs:
                    </span>
                  </span>
                  <div className="frame-frame8812">
                    <div className="frame-frame8809">
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="eicheck1016"
                        className="frame-eicheck"
                      />
                      <span className="frame-text155">
                        <span>On-premise</span>
                      </span>
                    </div>
                    <div className="frame-frame8810">
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="eicheck1016"
                        className="frame-eicheck1"
                      />
                      <span className="frame-text157">
                        <span>Cloud-хостинг</span>
                      </span>
                    </div>
                    <div className="frame-frame8811">
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="eicheck1016"
                        className="frame-eicheck2"
                      />
                      <span className="frame-text159">
                        <span>Hosted-модель</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <img
          src="/external/image1311016-wdln-700w.png"
          alt="IMAGE1311016"
          className="frame-image131"
        />
        <span className="frame-text161">
          <span>Integrate Im&apos;work now</span>
        </span>
        <span className="frame-text163">
          <span>
            You can make work communication more effective - just see how it
            works
          </span>
        </span>
        <span className="frame-text165">
          <span>App Store</span>
        </span>
        <span className="frame-text167">
          <span>Google Play</span>
        </span>
        <span className="frame-text169">
          <span>MacOS</span>
        </span>
        <span className="frame-text171">
          <span>Web version</span>
        </span>
        <span className="frame-text173">
          <span>Windows</span>
        </span>
        <img
          src="/external/rectangle1017-fdn-200h.png"
          alt="Rectangle1017"
          className="frame-rectangle02"
        />
        <img
          src="/external/rectangle1017-9o59-200h.png"
          alt="Rectangle1017"
          className="frame-rectangle03"
        />
        <img
          src="/external/rectangle1017-fzco-200h.png"
          alt="Rectangle1017"
          className="frame-rectangle04"
        />
        <img
          src="/external/rectangle1017-m0f-200h.png"
          alt="Rectangle1017"
          className="frame-rectangle05"
        />
        <img
          src="/external/rectangle1017-yv4c-200h.png"
          alt="Rectangle1017"
          className="frame-rectangle06"
        />
        <div className="frame-group135">
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector297"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector298"
          />
          <img src alt="Vector1017" className="frame-vector299" />
          <img src alt="Vector1017" className="frame-vector300" />
          <img src alt="Vector1017" className="frame-vector301" />
          <img src alt="Vector1017" className="frame-vector302" />
          <img src alt="Vector1017" className="frame-vector303" />
          <img src alt="Vector1017" className="frame-vector304" />
          <img src alt="Vector1017" className="frame-vector305" />
          <img src alt="Vector1017" className="frame-vector306" />
          <img src alt="Vector1017" className="frame-vector307" />
          <img src alt="Vector1017" className="frame-vector308" />
          <img src alt="Vector1017" className="frame-vector309" />
          <img src alt="Vector1017" className="frame-vector310" />
          <img src alt="Vector1017" className="frame-vector311" />
          <img src alt="Vector1017" className="frame-vector312" />
          <img src alt="Vector1017" className="frame-vector313" />
          <img src alt="Vector1017" className="frame-vector314" />
          <img src alt="Vector1017" className="frame-vector315" />
          <img src alt="Vector1017" className="frame-vector316" />
          <img src alt="Vector1017" className="frame-vector317" />
          <img src alt="Vector1017" className="frame-vector318" />
          <img src alt="Vector1017" className="frame-vector319" />
          <img src alt="Vector1017" className="frame-vector320" />
          <img src alt="Vector1017" className="frame-vector321" />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector322"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector323"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector324"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector325"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector326"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector327"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector328"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector329"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector330"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector331"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector332"
          />
          <img
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            alt="Vector1017"
            className="frame-vector333"
          />
          <img
            src="/external/vector1017-yvgj.svg"
            alt="Vector1017"
            className="frame-vector334"
          />
          <img
            src="/external/vector1017-qgnm.svg"
            alt="Vector1017"
            className="frame-vector335"
          />
          <img
            src="/external/vector1017-h1w4.svg"
            alt="Vector1017"
            className="frame-vector336"
          />
          <img
            src="/external/vector1017-o5b4.svg"
            alt="Vector1017"
            className="frame-vector337"
          />
          <img
            src="/external/vector1017-j8k.svg"
            alt="Vector1017"
            className="frame-vector338"
          />
          <img
            src="/external/vector1017-agta.svg"
            alt="Vector1017"
            className="frame-vector339"
          />
          <img
            src="/external/vector1017-qi6f.svg"
            alt="Vector1017"
            className="frame-vector340"
          />
          <img
            src="/external/vector1017-7azr.svg"
            alt="Vector1017"
            className="frame-vector341"
          />
          <img
            src="/external/vector1017-r5ul.svg"
            alt="Vector1017"
            className="frame-vector342"
          />
          <img
            src="/external/vector1017-92xl.svg"
            alt="Vector1017"
            className="frame-vector343"
          />
          <img
            src="/external/vector1017-99mo.svg"
            alt="Vector1017"
            className="frame-vector344"
          />
          <img
            src="/external/vector1017-ps14.svg"
            alt="Vector1017"
            className="frame-vector345"
          />
          <img
            src="/external/vector1017-vqmq.svg"
            alt="Vector1017"
            className="frame-vector346"
          />
          <img
            src="/external/vector1017-24jh.svg"
            alt="Vector1017"
            className="frame-vector347"
          />
          <img
            src="/external/vector1017-j519.svg"
            alt="Vector1017"
            className="frame-vector348"
          />
          <img
            src="/external/vector1017-lfpa.svg"
            alt="Vector1017"
            className="frame-vector349"
          />
        </div>
        <div className="frame-group136">
          <div className="frame-group137">
            <img
              src="/external/vector1017-wvja.svg"
              alt="Vector1017"
              className="frame-vector350"
            />
            <img
              src="/external/vector1017-by0d.svg"
              alt="Vector1017"
              className="frame-vector351"
            />
          </div>
          <div className="frame-group138">
            <img
              src="/external/vector1017-n17h.svg"
              alt="Vector1017"
              className="frame-vector352"
            />
            <img
              src="/external/vector1017-ybin.svg"
              alt="Vector1017"
              className="frame-vector353"
            />
          </div>
          <div className="frame-group139">
            <img
              src="/external/vector1017-jtii.svg"
              alt="Vector1017"
              className="frame-vector354"
            />
            <img
              src="/external/vector1017-dsq.svg"
              alt="Vector1017"
              className="frame-vector355"
            />
          </div>
          <div className="frame-group140">
            <img
              src="/external/vector1017-7lc.svg"
              alt="Vector1017"
              className="frame-vector356"
            />
            <img
              src="/external/vector1017-wr8b.svg"
              alt="Vector1017"
              className="frame-vector357"
            />
          </div>
          <div className="frame-group141">
            <img
              src="/external/vector1017-s1cc.svg"
              alt="Vector1017"
              className="frame-vector358"
            />
            <img
              src="/external/vector1017-38o.svg"
              alt="Vector1017"
              className="frame-vector359"
            />
          </div>
          <div className="frame-group142">
            <img
              src="/external/vector1017-wsvr.svg"
              alt="Vector1017"
              className="frame-vector360"
            />
            <img
              src="/external/vector1017-1nd6.svg"
              alt="Vector1017"
              className="frame-vector361"
            />
          </div>
          <div className="frame-group143">
            <img
              src="/external/vector1017-dejw.svg"
              alt="Vector1017"
              className="frame-vector362"
            />
            <img
              src="/external/vector1017-yo15.svg"
              alt="Vector1017"
              className="frame-vector363"
            />
          </div>
          <div className="frame-group144">
            <div className="frame-group145">
              <img
                src="/external/vector1017-i51f.svg"
                alt="Vector1017"
                className="frame-vector364"
              />
              <img
                src="/external/vector1017-n3el.svg"
                alt="Vector1017"
                className="frame-vector365"
              />
            </div>
            <div className="frame-group146">
              <img
                src="/external/vector1017-2vr.svg"
                alt="Vector1017"
                className="frame-vector366"
              />
              <img
                src="/external/vector1017-q8a.svg"
                alt="Vector1017"
                className="frame-vector367"
              />
            </div>
            <div className="frame-group147">
              <img
                src="/external/vector1017-4b3b.svg"
                alt="Vector1017"
                className="frame-vector368"
              />
              <img
                src="/external/vector1017-ej6i.svg"
                alt="Vector1017"
                className="frame-vector369"
              />
            </div>
          </div>
        </div>
        <div className="frame-group148">
          <div className="frame-group149">
            <img
              src="/external/vector1017-7fcsc.svg"
              alt="Vector1017"
              className="frame-vector370"
            />
            <img
              src="/external/vector1017-f0ll.svg"
              alt="Vector1017"
              className="frame-vector371"
            />
          </div>
          <div className="frame-group150">
            <img
              src="/external/vector1018-hze.svg"
              alt="Vector1018"
              className="frame-vector372"
            />
            <img
              src="/external/vector1018-y01.svg"
              alt="Vector1018"
              className="frame-vector373"
            />
          </div>
          <div className="frame-group151">
            <img
              src="/external/vector1018-muyc.svg"
              alt="Vector1018"
              className="frame-vector374"
            />
            <img
              src="/external/vector1018-4myl.svg"
              alt="Vector1018"
              className="frame-vector375"
            />
          </div>
          <div className="frame-group152">
            <img
              src="/external/vector1018-0tvl.svg"
              alt="Vector1018"
              className="frame-vector376"
            />
            <img
              src="/external/vector1018-cxql.svg"
              alt="Vector1018"
              className="frame-vector377"
            />
          </div>
          <div className="frame-group153">
            <img
              src="/external/vector1018-mab.svg"
              alt="Vector1018"
              className="frame-vector378"
            />
            <img
              src="/external/vector1018-nah.svg"
              alt="Vector1018"
              className="frame-vector379"
            />
          </div>
          <div className="frame-group154">
            <img
              src="/external/vector1018-61ps.svg"
              alt="Vector1018"
              className="frame-vector380"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1018"
              className="frame-vector381"
            />
          </div>
          <div className="frame-group155">
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1018"
              className="frame-vector382"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Vector1018"
              className="frame-vector383"
            />
          </div>
          <div className="frame-group156">
            <div className="frame-group157">
              <img
                src="/external/vector1018-r6sl.svg"
                alt="Vector1018"
                className="frame-vector384"
              />
              <img
                src="/external/vector1018-ou9o.svg"
                alt="Vector1018"
                className="frame-vector385"
              />
            </div>
            <div className="frame-group158">
              <img
                src="/external/vector1018-cl3q.svg"
                alt="Vector1018"
                className="frame-vector386"
              />
              <img
                src="/external/vector1018-148p.svg"
                alt="Vector1018"
                className="frame-vector387"
              />
            </div>
            <div className="frame-group159">
              <img
                src="/external/vector1018-8gr5r.svg"
                alt="Vector1018"
                className="frame-vector388"
              />
              <img
                src="/external/vector1018-dspa.svg"
                alt="Vector1018"
                className="frame-vector389"
              />
            </div>
          </div>
        </div>
        <img
          src="/external/frame1018-ykp8.svg"
          alt="Frame1018"
          className="frame-frame04"
        />
        <img
          src="/external/frame1018-5ht8i.svg"
          alt="Frame1018"
          className="frame-frame05"
        />
        <img
          src="/external/frame1018-oshm.svg"
          alt="Frame1018"
          className="frame-frame06"
        />
        <img
          src="/external/frame1018-tmi8.svg"
          alt="Frame1018"
          className="frame-frame07"
        />
        <img
          src="/external/frame1018-nhkm.svg"
          alt="Frame1018"
          className="frame-frame08"
        />
        <span className="frame-text175">
          <span>Im&apos;work partners</span>
        </span>
        <span className="frame-text177">
          <span>
            Im&apos;work runs on Android and IOS platforms, supports Windows,
            Mac OS, Linux operating systems, and is also available as a web
            application
          </span>
        </span>
        <img
          src="/external/ellipse99791018-txb-700w.png"
          alt="Ellipse99791018"
          className="frame-ellipse99791"
        />
        <img
          src="/external/rectangle346241331018-f6u9h-200h.png"
          alt="Rectangle346241331018"
          className="frame-rectangle34624133"
        />
        <img
          src="/external/rectangle346241391018-6ae-300w.png"
          alt="Rectangle346241391018"
          className="frame-rectangle34624139"
        />
        <img
          src="/external/rectangle346241411018-7q2l-300w.png"
          alt="Rectangle346241411018"
          className="frame-rectangle34624141"
        />
        <img
          src="/external/rectangle346241431018-opmh-300w.png"
          alt="Rectangle346241431018"
          className="frame-rectangle34624143"
        />
        <img
          src="/external/rectangle346241401018-atz-300w.png"
          alt="Rectangle346241401018"
          className="frame-rectangle34624140"
        />
        <img
          src="/external/rectangle346241441018-x84-300w.png"
          alt="Rectangle346241441018"
          className="frame-rectangle34624144"
        />
        <img
          src="/external/rectangle346241421018-plwm-300w.png"
          alt="Rectangle346241421018"
          className="frame-rectangle34624142"
        />
        <img
          src="/external/rectangle346241361018-4x2-200h.png"
          alt="Rectangle346241361018"
          className="frame-rectangle34624136"
        />
        <img
          src="/external/rectangle346241341018-okx-200h.png"
          alt="Rectangle346241341018"
          className="frame-rectangle34624134"
        />
        <img
          src="/external/rectangle346241371018-5zyu-200h.png"
          alt="Rectangle346241371018"
          className="frame-rectangle34624137"
        />
        <img
          src="/external/rectangle346241351018-276-200h.png"
          alt="Rectangle346241351018"
          className="frame-rectangle34624135"
        />
        <img
          src="/external/rectangle346241381018-rjx8-200h.png"
          alt="Rectangle346241381018"
          className="frame-rectangle34624138"
        />
        <span className="frame-text179">
          <span>Web</span>
        </span>
        <span className="frame-text181">
          <span>iOS</span>
        </span>
        <span className="frame-text183">
          <span>Android</span>
        </span>
        <span className="frame-text185">
          <span>Windows</span>
        </span>
        <span className="frame-text187">
          <span>Mac OS</span>
        </span>
        <span className="frame-text189">
          <span>Linux</span>
        </span>
        <img
          src="/external/frame1018-ejie.svg"
          alt="Frame1018"
          className="frame-frame09"
        />
        <img
          src="/external/frame1018-0kye.svg"
          alt="Frame1018"
          className="frame-frame10"
        />
        <img
          src="/external/frame1018-bnn.svg"
          alt="Frame1018"
          className="frame-frame11"
        />
        <img
          src="/external/frame1018-8dzb.svg"
          alt="Frame1018"
          className="frame-frame12"
        />
        <img
          src="/external/frame1018-9vk.svg"
          alt="Frame1018"
          className="frame-frame13"
        />
        <img
          src="/external/frame1018-mom.svg"
          alt="Frame1018"
          className="frame-frame14"
        />
        <img
          src="/external/frame1018-4b4h.svg"
          alt="Frame1018"
          className="frame-frame15"
        />
        <img
          src="/external/frame1018-c69p.svg"
          alt="Frame1018"
          className="frame-frame16"
        />
        <img
          src="/external/frame1018-lrdk.svg"
          alt="Frame1018"
          className="frame-frame17"
        />
        <img
          src="/external/frame1018-giaa.svg"
          alt="Frame1018"
          className="frame-frame18"
        />
        <img
          src="/external/frame1019-jxcx.svg"
          alt="Frame1019"
          className="frame-frame19"
        />
        <img
          src="/external/frame1019-fn.svg"
          alt="Frame1019"
          className="frame-frame20"
        />
        <span className="frame-text191">
          <span>Receive a personal offer</span>
        </span>
        <span className="frame-text193">
          <span>
            We are ready to offer you a personal solution, depending on your
            needs, business objectives and company size
          </span>
        </span>
        <img
          src="/external/rectangle1019-s8a-1200w.png"
          alt="Rectangle1019"
          className="frame-rectangle07"
        />
        <img
          src="/external/rectangle1019-nt9-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle08"
        />
        <img
          src="/external/rectangle1019-uknm-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle09"
        />
        <img
          src="/external/rectangle1019-3dxn-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle10"
        />
        <img
          src="/external/rectangle1019-vxyc-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle11"
        />
        <img
          src="/external/rectangle1019-x7lp-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle12"
        />
        <img
          src="/external/rectangle1019-d1yf-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle13"
        />
        <img
          src="/external/rectangle1019-iwc-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle14"
        />
        <img
          src="/external/rectangle1019-z94-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle15"
        />
        <img
          src="/external/rectangle1019-x4k-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle16"
        />
        <img
          src="/external/rectangle1019-vfsp-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle17"
        />
        <img
          src="/external/rectangle1019-18wh-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle18"
        />
        <span className="frame-text195">
          <span>Your name:</span>
        </span>
        <span className="frame-text197">
          <span>Company name:</span>
        </span>
        <span className="frame-text199">
          <span>Email*:</span>
        </span>
        <span className="frame-text201">
          <span>Number of users:</span>
        </span>
        <span className="frame-text203">
          <span>Telephone*:</span>
        </span>
        <img
          src="/external/rectangle1019-esfd-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle19"
        />
        <img
          src="/external/rectangle1019-wb8b-600w.png"
          alt="Rectangle1019"
          className="frame-rectangle20"
        />
        <img
          src="/external/rectangle1019-i6gd-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle21"
        />
        <img
          src="/external/rectangle1019-e3ht-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle22"
        />
        <img
          src="/external/rectangle1019-min-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle23"
        />
        <img
          src="/external/rectangle1019-jzvs-200h.png"
          alt="Rectangle1019"
          className="frame-rectangle24"
        />
        <span className="frame-text205">
          <span>
            By clicking the “Send” button I agree to the processing of personal
            data
          </span>
        </span>
        <div className="frame-frame21">
          <div className="frame-group160">
            <div className="frame-frame22">
              <div className="frame-group161">
                <div className="frame-group162">
                  <div className="frame-group163">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector390"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector391"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector392"
                    />
                    <div className="frame-group164">
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector393"
                      />
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector394"
                      />
                    </div>
                    <div className="frame-group165">
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector395"
                      />
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector396"
                      />
                    </div>
                  </div>
                  <div className="frame-group166">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector397"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector398"
                    />
                  </div>
                  <div className="frame-group167">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector399"
                    />
                    <div className="frame-group168">
                      <div className="frame-group169">
                        <img
                          src="/external/vector1019-j2h.svg"
                          alt="Vector1019"
                          className="frame-vector400"
                        />
                        <div className="frame-group170">
                          <img
                            src="/external/vector1019-vuz3.svg"
                            alt="Vector1019"
                            className="frame-vector401"
                          />
                          <img
                            src="/external/vector1019-6kj.svg"
                            alt="Vector1019"
                            className="frame-vector402"
                          />
                          <img
                            src="/external/vector1019-o3ai.svg"
                            alt="Vector1019"
                            className="frame-vector403"
                          />
                          <img
                            src="/external/vector1019-0rn7.svg"
                            alt="Vector1019"
                            className="frame-vector404"
                          />
                          <img
                            src="/external/vector1019-rhm7.svg"
                            alt="Vector1019"
                            className="frame-vector405"
                          />
                          <img
                            src="/external/vector1019-hqh.svg"
                            alt="Vector1019"
                            className="frame-vector406"
                          />
                          <img
                            src="/external/vector1019-f9rh.svg"
                            alt="Vector1019"
                            className="frame-vector407"
                          />
                          <img
                            src="/external/vector1019-3bye.svg"
                            alt="Vector1019"
                            className="frame-vector408"
                          />
                          <img
                            src="/external/vector1019-gsi.svg"
                            alt="Vector1019"
                            className="frame-vector409"
                          />
                          <img
                            src="/external/vector1019-5a3a.svg"
                            alt="Vector1019"
                            className="frame-vector410"
                          />
                          <img
                            src="/external/vector1019-2bcm.svg"
                            alt="Vector1019"
                            className="frame-vector411"
                          />
                          <img
                            src="/external/vector1019-ii.svg"
                            alt="Vector1019"
                            className="frame-vector412"
                          />
                        </div>
                        <img
                          src="/external/vector1019-0vp5.svg"
                          alt="Vector1019"
                          className="frame-vector413"
                        />
                        <img
                          src="/external/vector1019-obsq.svg"
                          alt="Vector1019"
                          className="frame-vector414"
                        />
                      </div>
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector415"
                      />
                      <img
                        src="https://play.teleporthq.io/static/svg/default-img.svg"
                        alt="Vector1019"
                        className="frame-vector416"
                      />
                      <img
                        src="/external/vector1019-hqk.svg"
                        alt="Vector1019"
                        className="frame-vector417"
                      />
                      <div className="frame-group171">
                        <img
                          src="/external/vector1019-dbw3.svg"
                          alt="Vector1019"
                          className="frame-vector418"
                        />
                        <img
                          src="/external/vector1019-vwx.svg"
                          alt="Vector1019"
                          className="frame-vector419"
                        />
                        <span className="frame-text207">
                          <span>55%</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="frame-group172">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1019"
                      className="frame-vector420"
                    />
                    <div className="frame-group173">
                      <img
                        src="/external/vector1019-tzuu.svg"
                        alt="Vector1019"
                        className="frame-vector421"
                      />
                      <img
                        src="/external/vector1019-hfyj.svg"
                        alt="Vector1019"
                        className="frame-vector422"
                      />
                      <img
                        src="/external/vector1019-q6z5.svg"
                        alt="Vector1019"
                        className="frame-vector423"
                      />
                      <img
                        src="/external/vector1019-y58.svg"
                        alt="Vector1019"
                        className="frame-vector424"
                      />
                    </div>
                    <div className="frame-group174">
                      <img
                        src="/external/vector1019-cwme.svg"
                        alt="Vector1019"
                        className="frame-vector425"
                      />
                      <img
                        src="/external/vector1019-64js.svg"
                        alt="Vector1019"
                        className="frame-vector426"
                      />
                      <img
                        src="/external/vector1019-ifyc.svg"
                        alt="Vector1019"
                        className="frame-vector427"
                      />
                      <img
                        src="/external/vector1019-1alr.svg"
                        alt="Vector1019"
                        className="frame-vector428"
                      />
                    </div>
                    <div className="frame-group175">
                      <div className="frame-group176">
                        <img
                          src="/external/vector1019-7t9.svg"
                          alt="Vector1019"
                          className="frame-vector429"
                        />
                        <img
                          src="/external/vector1019-mndn.svg"
                          alt="Vector1019"
                          className="frame-vector430"
                        />
                      </div>
                      <div className="frame-group177">
                        <img
                          src="/external/vector1011-l06r.svg"
                          alt="Vector1011"
                          className="frame-vector431"
                        />
                        <img
                          src="/external/vector1011-cvyg.svg"
                          alt="Vector1011"
                          className="frame-vector432"
                        />
                      </div>
                      <div className="frame-group178">
                        <img
                          src="/external/vector1011-oqpj.svg"
                          alt="Vector1011"
                          className="frame-vector433"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector434"
                        />
                      </div>
                      <div className="frame-group179">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector435"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector436"
                        />
                      </div>
                      <div className="frame-group180">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector437"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector438"
                        />
                      </div>
                      <div className="frame-group181">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector439"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector440"
                        />
                      </div>
                      <div className="frame-group182">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector441"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector442"
                        />
                      </div>
                      <div className="frame-group183">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector443"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector444"
                        />
                      </div>
                      <div className="frame-group184">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector445"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector446"
                        />
                      </div>
                      <div className="frame-group185">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector447"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector448"
                        />
                      </div>
                      <div className="frame-group186">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector449"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector450"
                        />
                      </div>
                      <div className="frame-group187">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector451"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector452"
                        />
                      </div>
                      <div className="frame-group188">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector453"
                        />
                        <img
                          src="/external/vector1011-lnr.svg"
                          alt="Vector1011"
                          className="frame-vector454"
                        />
                      </div>
                      <div className="frame-group189">
                        <img
                          src="/external/vector1011-7psr.svg"
                          alt="Vector1011"
                          className="frame-vector455"
                        />
                        <img
                          src="/external/vector1011-5oig.svg"
                          alt="Vector1011"
                          className="frame-vector456"
                        />
                      </div>
                      <div className="frame-group190">
                        <img
                          src="/external/vector1011-huvk.svg"
                          alt="Vector1011"
                          className="frame-vector457"
                        />
                        <img
                          src="/external/vector1011-0fm.svg"
                          alt="Vector1011"
                          className="frame-vector458"
                        />
                      </div>
                      <div className="frame-group191">
                        <img
                          src="/external/vector1011-m1w.svg"
                          alt="Vector1011"
                          className="frame-vector459"
                        />
                        <img
                          src="/external/vector1011-e7u.svg"
                          alt="Vector1011"
                          className="frame-vector460"
                        />
                      </div>
                      <div className="frame-group192">
                        <img
                          src="/external/vector1011-c2jh.svg"
                          alt="Vector1011"
                          className="frame-vector461"
                        />
                        <img
                          src="/external/vector1011-723n.svg"
                          alt="Vector1011"
                          className="frame-vector462"
                        />
                      </div>
                      <div className="frame-group193">
                        <img
                          src="/external/vector1011-6yri.svg"
                          alt="Vector1011"
                          className="frame-vector463"
                        />
                        <img
                          src="/external/vector1011-iu0o.svg"
                          alt="Vector1011"
                          className="frame-vector464"
                        />
                      </div>
                      <div className="frame-group194">
                        <img
                          src="/external/vector1011-p31c.svg"
                          alt="Vector1011"
                          className="frame-vector465"
                        />
                        <img
                          src="/external/vector1011-3ho.svg"
                          alt="Vector1011"
                          className="frame-vector466"
                        />
                      </div>
                      <div className="frame-group195">
                        <img
                          src="/external/vector1011-wm79.svg"
                          alt="Vector1011"
                          className="frame-vector467"
                        />
                        <img
                          src="/external/vector1011-h6sa.svg"
                          alt="Vector1011"
                          className="frame-vector468"
                        />
                      </div>
                      <div className="frame-group196">
                        <img
                          src="/external/vector1011-kzic.svg"
                          alt="Vector1011"
                          className="frame-vector469"
                        />
                        <img
                          src="/external/vector1011-2gi.svg"
                          alt="Vector1011"
                          className="frame-vector470"
                        />
                      </div>
                      <div className="frame-group197">
                        <img
                          src="/external/vector1011-y0a.svg"
                          alt="Vector1011"
                          className="frame-vector471"
                        />
                        <img
                          src="/external/vector1011-tzds.svg"
                          alt="Vector1011"
                          className="frame-vector472"
                        />
                      </div>
                      <div className="frame-group198">
                        <img
                          src="/external/vector1011-c03j.svg"
                          alt="Vector1011"
                          className="frame-vector473"
                        />
                        <img
                          src="/external/vector1011-7svo.svg"
                          alt="Vector1011"
                          className="frame-vector474"
                        />
                      </div>
                      <div className="frame-group199">
                        <div className="frame-group200">
                          <img
                            src="/external/vector1011-07pm.svg"
                            alt="Vector1011"
                            className="frame-vector475"
                          />
                          <img
                            src="/external/vector1011-8ymm.svg"
                            alt="Vector1011"
                            className="frame-vector476"
                          />
                        </div>
                        <div className="frame-group201">
                          <img
                            src="/external/vector1011-zeed.svg"
                            alt="Vector1011"
                            className="frame-vector477"
                          />
                          <img
                            src="/external/vector1011-mppn.svg"
                            alt="Vector1011"
                            className="frame-vector478"
                          />
                        </div>
                        <div className="frame-group202">
                          <img
                            src="/external/vector1011-vl6j.svg"
                            alt="Vector1011"
                            className="frame-vector479"
                          />
                          <img
                            src="/external/vector1011-93gb.svg"
                            alt="Vector1011"
                            className="frame-vector480"
                          />
                        </div>
                        <div className="frame-group203">
                          <img
                            src="/external/vector1011-b9ki.svg"
                            alt="Vector1011"
                            className="frame-vector481"
                          />
                          <img
                            src="/external/vector1011-15du.svg"
                            alt="Vector1011"
                            className="frame-vector482"
                          />
                        </div>
                        <div className="frame-group204">
                          <img
                            src="/external/vector1011-f9we.svg"
                            alt="Vector1011"
                            className="frame-vector483"
                          />
                          <img
                            src="/external/vector1011-srtd.svg"
                            alt="Vector1011"
                            className="frame-vector484"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="frame-group205">
                      <div className="frame-group206">
                        <img
                          src="/external/vector1011-sq7d.svg"
                          alt="Vector1011"
                          className="frame-vector485"
                        />
                        <img
                          src="/external/vector1011-2fu.svg"
                          alt="Vector1011"
                          className="frame-vector486"
                        />
                      </div>
                      <div className="frame-group207">
                        <img
                          src="/external/vector1011-bo4.svg"
                          alt="Vector1011"
                          className="frame-vector487"
                        />
                        <img
                          src="/external/vector1011-btgm.svg"
                          alt="Vector1011"
                          className="frame-vector488"
                        />
                      </div>
                      <div className="frame-group208">
                        <img
                          src="/external/vector1011-gm8r.svg"
                          alt="Vector1011"
                          className="frame-vector489"
                        />
                        <img
                          src="/external/vector1011-leac.svg"
                          alt="Vector1011"
                          className="frame-vector490"
                        />
                      </div>
                      <div className="frame-group209">
                        <img
                          src="/external/vector1011-atitf.svg"
                          alt="Vector1011"
                          className="frame-vector491"
                        />
                        <img
                          src="/external/vector1011-ywjq.svg"
                          alt="Vector1011"
                          className="frame-vector492"
                        />
                      </div>
                      <div className="frame-group210">
                        <img
                          src="/external/vector1011-m5j7.svg"
                          alt="Vector1011"
                          className="frame-vector493"
                        />
                        <img
                          src="/external/vector1011-fb1p.svg"
                          alt="Vector1011"
                          className="frame-vector494"
                        />
                      </div>
                      <div className="frame-group211">
                        <img
                          src="/external/vector1011-xpvn.svg"
                          alt="Vector1011"
                          className="frame-vector495"
                        />
                        <img
                          src="/external/vector1011-bur.svg"
                          alt="Vector1011"
                          className="frame-vector496"
                        />
                      </div>
                      <div className="frame-group212">
                        <img
                          src="/external/vector1011-8dir.svg"
                          alt="Vector1011"
                          className="frame-vector497"
                        />
                        <img
                          src="/external/vector1011-ix07.svg"
                          alt="Vector1011"
                          className="frame-vector498"
                        />
                      </div>
                      <div className="frame-group213">
                        <img
                          src="/external/vector1011-a3o.svg"
                          alt="Vector1011"
                          className="frame-vector499"
                        />
                        <img
                          src="/external/vector1011-9uq.svg"
                          alt="Vector1011"
                          className="frame-vector500"
                        />
                      </div>
                      <div className="frame-group214">
                        <img
                          src="/external/vector1011-e9nh.svg"
                          alt="Vector1011"
                          className="frame-vector501"
                        />
                        <img
                          src="/external/vector1011-c4e.svg"
                          alt="Vector1011"
                          className="frame-vector502"
                        />
                      </div>
                      <div className="frame-group215">
                        <img
                          src="/external/vector1011-rzfm.svg"
                          alt="Vector1011"
                          className="frame-vector503"
                        />
                        <img
                          src="/external/vector1011-5cgd.svg"
                          alt="Vector1011"
                          className="frame-vector504"
                        />
                      </div>
                      <div className="frame-group216">
                        <img
                          src="/external/vector1011-xyk.svg"
                          alt="Vector1011"
                          className="frame-vector505"
                        />
                        <img
                          src="/external/vector1011-22v8.svg"
                          alt="Vector1011"
                          className="frame-vector506"
                        />
                      </div>
                      <div className="frame-group217">
                        <img
                          src="/external/vector1011-ak6l.svg"
                          alt="Vector1011"
                          className="frame-vector507"
                        />
                        <img
                          src="/external/vector1011-w69k.svg"
                          alt="Vector1011"
                          className="frame-vector508"
                        />
                      </div>
                      <div className="frame-group218">
                        <img
                          src="/external/vector1011-tmh.svg"
                          alt="Vector1011"
                          className="frame-vector509"
                        />
                        <img
                          src="/external/vector1011-jogs.svg"
                          alt="Vector1011"
                          className="frame-vector510"
                        />
                      </div>
                      <div className="frame-group219">
                        <img
                          src="/external/vector1011-9gu.svg"
                          alt="Vector1011"
                          className="frame-vector511"
                        />
                        <img
                          src="/external/vector1011-539.svg"
                          alt="Vector1011"
                          className="frame-vector512"
                        />
                      </div>
                      <div className="frame-group220">
                        <img
                          src="/external/vector1011-38hm.svg"
                          alt="Vector1011"
                          className="frame-vector513"
                        />
                        <img
                          src="/external/vector1011-qcvi.svg"
                          alt="Vector1011"
                          className="frame-vector514"
                        />
                      </div>
                      <div className="frame-group221">
                        <img
                          src="/external/vector1011-u3a.svg"
                          alt="Vector1011"
                          className="frame-vector515"
                        />
                        <img
                          src="/external/vector1011-e5c.svg"
                          alt="Vector1011"
                          className="frame-vector516"
                        />
                      </div>
                      <div className="frame-group222">
                        <img
                          src="/external/vector1011-yd8n.svg"
                          alt="Vector1011"
                          className="frame-vector517"
                        />
                        <img
                          src="/external/vector1011-33qa.svg"
                          alt="Vector1011"
                          className="frame-vector518"
                        />
                      </div>
                      <div className="frame-group223">
                        <img
                          src="/external/vector1011-04c8.svg"
                          alt="Vector1011"
                          className="frame-vector519"
                        />
                        <img
                          src="/external/vector1011-3j3.svg"
                          alt="Vector1011"
                          className="frame-vector520"
                        />
                      </div>
                      <div className="frame-group224">
                        <img
                          src="/external/vector1011-s9nt.svg"
                          alt="Vector1011"
                          className="frame-vector521"
                        />
                        <img
                          src="/external/vector1011-onek.svg"
                          alt="Vector1011"
                          className="frame-vector522"
                        />
                      </div>
                      <div className="frame-group225">
                        <img
                          src="/external/vector1011-awt9.svg"
                          alt="Vector1011"
                          className="frame-vector523"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector524"
                        />
                      </div>
                      <div className="frame-group226">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector525"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector526"
                        />
                      </div>
                      <div className="frame-group227">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector527"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector528"
                        />
                      </div>
                      <div className="frame-group228">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector529"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector530"
                        />
                      </div>
                      <div className="frame-group229">
                        <div className="frame-group230">
                          <img
                            src="/external/vector1011-guu.svg"
                            alt="Vector1011"
                            className="frame-vector531"
                          />
                          <img
                            src="/external/vector1011-fbwu.svg"
                            alt="Vector1011"
                            className="frame-vector532"
                          />
                        </div>
                        <div className="frame-group231">
                          <img
                            src="/external/vector1011-v5w8.svg"
                            alt="Vector1011"
                            className="frame-vector533"
                          />
                          <img
                            src="/external/vector1011-ig9.svg"
                            alt="Vector1011"
                            className="frame-vector534"
                          />
                        </div>
                        <div className="frame-group232">
                          <img
                            src="/external/vector1011-165s.svg"
                            alt="Vector1011"
                            className="frame-vector535"
                          />
                          <img
                            src="/external/vector1011-b47t.svg"
                            alt="Vector1011"
                            className="frame-vector536"
                          />
                        </div>
                        <div className="frame-group233">
                          <img
                            src="/external/vector1011-taiv.svg"
                            alt="Vector1011"
                            className="frame-vector537"
                          />
                          <img
                            src="/external/vector1011-yb1.svg"
                            alt="Vector1011"
                            className="frame-vector538"
                          />
                        </div>
                        <div className="frame-group234">
                          <img
                            src="/external/vector1011-hd7or.svg"
                            alt="Vector1011"
                            className="frame-vector539"
                          />
                          <img
                            src="/external/vector1011-9kth.svg"
                            alt="Vector1011"
                            className="frame-vector540"
                          />
                        </div>
                      </div>
                    </div>
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector541"
                    />
                  </div>
                  <div className="frame-group235">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector542"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector543"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector544"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector545"
                    />
                  </div>
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector546"
                  />
                  <div className="frame-group236">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector547"
                    />
                    <div className="frame-group237">
                      <div className="frame-group238">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector548"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector549"
                        />
                      </div>
                      <div className="frame-group239">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector550"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector551"
                        />
                      </div>
                      <div className="frame-group240">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector552"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector553"
                        />
                      </div>
                      <div className="frame-group241">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector554"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector555"
                        />
                      </div>
                      <div className="frame-group242">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector556"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector557"
                        />
                      </div>
                      <div className="frame-group243">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector558"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector559"
                        />
                      </div>
                      <div className="frame-group244">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="Vector1011"
                          className="frame-vector560"
                        />
                        <img
                          src="/external/vector1011-rt4j.svg"
                          alt="Vector1011"
                          className="frame-vector561"
                        />
                      </div>
                      <div className="frame-group245">
                        <img
                          src="/external/vector1011-rrjr.svg"
                          alt="Vector1011"
                          className="frame-vector562"
                        />
                        <img
                          src="/external/vector1011-73i7.svg"
                          alt="Vector1011"
                          className="frame-vector563"
                        />
                      </div>
                      <div className="frame-group246">
                        <img
                          src="/external/vector1011-5ntto.svg"
                          alt="Vector1011"
                          className="frame-vector564"
                        />
                        <img
                          src="/external/vector1011-58zn.svg"
                          alt="Vector1011"
                          className="frame-vector565"
                        />
                      </div>
                      <div className="frame-group247">
                        <img
                          src="/external/vector1011-jqc.svg"
                          alt="Vector1011"
                          className="frame-vector566"
                        />
                        <img
                          src="/external/vector1011-sgoe.svg"
                          alt="Vector1011"
                          className="frame-vector567"
                        />
                      </div>
                      <div className="frame-group248">
                        <img
                          src="/external/vector1011-e0yl.svg"
                          alt="Vector1011"
                          className="frame-vector568"
                        />
                        <img
                          src="/external/vector1011-b1bd.svg"
                          alt="Vector1011"
                          className="frame-vector569"
                        />
                      </div>
                      <div className="frame-group249">
                        <img
                          src="/external/vector1011-oln.svg"
                          alt="Vector1011"
                          className="frame-vector570"
                        />
                        <img
                          src="/external/vector1011-kdyh.svg"
                          alt="Vector1011"
                          className="frame-vector571"
                        />
                      </div>
                      <div className="frame-group250">
                        <img
                          src="/external/vector1011-ns7o.svg"
                          alt="Vector1011"
                          className="frame-vector572"
                        />
                        <img
                          src="/external/vector1011-05uv.svg"
                          alt="Vector1011"
                          className="frame-vector573"
                        />
                      </div>
                      <div className="frame-group251">
                        <img
                          src="/external/vector1011-95ks.svg"
                          alt="Vector1011"
                          className="frame-vector574"
                        />
                        <img
                          src="/external/vector1011-4k2d.svg"
                          alt="Vector1011"
                          className="frame-vector575"
                        />
                      </div>
                      <div className="frame-group252">
                        <img
                          src="/external/vector1011-u6k.svg"
                          alt="Vector1011"
                          className="frame-vector576"
                        />
                        <img
                          src="/external/vector1011-b95.svg"
                          alt="Vector1011"
                          className="frame-vector577"
                        />
                      </div>
                      <div className="frame-group253">
                        <img
                          src="/external/vector1011-ibco.svg"
                          alt="Vector1011"
                          className="frame-vector578"
                        />
                        <img
                          src="/external/vector1011-or2.svg"
                          alt="Vector1011"
                          className="frame-vector579"
                        />
                      </div>
                      <div className="frame-group254">
                        <img
                          src="/external/vector1011-mi2l.svg"
                          alt="Vector1011"
                          className="frame-vector580"
                        />
                        <img
                          src="/external/vector1011-9qv.svg"
                          alt="Vector1011"
                          className="frame-vector581"
                        />
                      </div>
                      <div className="frame-group255">
                        <img
                          src="/external/vector1011-2tyc.svg"
                          alt="Vector1011"
                          className="frame-vector582"
                        />
                        <img
                          src="/external/vector1011-wn2i.svg"
                          alt="Vector1011"
                          className="frame-vector583"
                        />
                      </div>
                      <div className="frame-group256">
                        <img
                          src="/external/vector1011-hr7c.svg"
                          alt="Vector1011"
                          className="frame-vector584"
                        />
                        <img
                          src="/external/vector1011-3yd.svg"
                          alt="Vector1011"
                          className="frame-vector585"
                        />
                      </div>
                      <div className="frame-group257">
                        <img
                          src="/external/vector1011-1ci1.svg"
                          alt="Vector1011"
                          className="frame-vector586"
                        />
                        <img
                          src="/external/vector1011-c6c.svg"
                          alt="Vector1011"
                          className="frame-vector587"
                        />
                      </div>
                      <div className="frame-group258">
                        <img
                          src="/external/vector1011-yu6.svg"
                          alt="Vector1011"
                          className="frame-vector588"
                        />
                        <img
                          src="/external/vector1011-5mn.svg"
                          alt="Vector1011"
                          className="frame-vector589"
                        />
                      </div>
                      <div className="frame-group259">
                        <img
                          src="/external/vector1011-ghc.svg"
                          alt="Vector1011"
                          className="frame-vector590"
                        />
                        <img
                          src="/external/vector1011-ye06.svg"
                          alt="Vector1011"
                          className="frame-vector591"
                        />
                      </div>
                      <div className="frame-group260">
                        <img
                          src="/external/vector1011-pt8s.svg"
                          alt="Vector1011"
                          className="frame-vector592"
                        />
                        <img
                          src="/external/vector1011-d46h.svg"
                          alt="Vector1011"
                          className="frame-vector593"
                        />
                      </div>
                      <div className="frame-group261">
                        <div className="frame-group262">
                          <img
                            src="/external/vector1011-mwm4h.svg"
                            alt="Vector1011"
                            className="frame-vector594"
                          />
                          <img
                            src="/external/vector1011-q6bj.svg"
                            alt="Vector1011"
                            className="frame-vector595"
                          />
                        </div>
                        <div className="frame-group263">
                          <img
                            src="/external/vector1011-34h7.svg"
                            alt="Vector1011"
                            className="frame-vector596"
                          />
                          <img
                            src="/external/vector1011-73s.svg"
                            alt="Vector1011"
                            className="frame-vector597"
                          />
                        </div>
                        <div className="frame-group264">
                          <img
                            src="/external/vector1011-hlpp.svg"
                            alt="Vector1011"
                            className="frame-vector598"
                          />
                          <img
                            src="/external/vector1011-lyfhb.svg"
                            alt="Vector1011"
                            className="frame-vector599"
                          />
                        </div>
                        <div className="frame-group265">
                          <img
                            src="/external/vector1011-ba47.svg"
                            alt="Vector1011"
                            className="frame-vector600"
                          />
                          <img
                            src="/external/vector1011-6mcl.svg"
                            alt="Vector1011"
                            className="frame-vector601"
                          />
                        </div>
                        <div className="frame-group266">
                          <img
                            src="/external/vector1011-aqe.svg"
                            alt="Vector1011"
                            className="frame-vector602"
                          />
                          <img
                            src="/external/vector1011-xjb7.svg"
                            alt="Vector1011"
                            className="frame-vector603"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame-group267">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector604"
                    />
                    <div className="frame-group268">
                      <img
                        src="/external/vector1011-76fe.svg"
                        alt="Vector1011"
                        className="frame-vector605"
                      />
                      <img
                        src="/external/vector1011-qs6.svg"
                        alt="Vector1011"
                        className="frame-vector606"
                      />
                      <img
                        src="/external/vector1011-2bi9.svg"
                        alt="Vector1011"
                        className="frame-vector607"
                      />
                      <img
                        src="/external/vector1011-vwzk.svg"
                        alt="Vector1011"
                        className="frame-vector608"
                      />
                      <img
                        src="/external/vector1011-l4md.svg"
                        alt="Vector1011"
                        className="frame-vector609"
                      />
                      <img
                        src="/external/vector1011-y0fr.svg"
                        alt="Vector1011"
                        className="frame-vector610"
                      />
                      <img
                        src="/external/vector1011-yrj9.svg"
                        alt="Vector1011"
                        className="frame-vector611"
                      />
                    </div>
                  </div>
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector612"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector613"
                  />
                  <div className="frame-group269">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector614"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector615"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector616"
                    />
                  </div>
                  <div className="frame-group270">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector617"
                    />
                    <div className="frame-group271">
                      <div className="frame-group272">
                        <img
                          src="/external/vector1011-qir3.svg"
                          alt="Vector1011"
                          className="frame-vector618"
                        />
                        <img
                          src="/external/vector1011-xln.svg"
                          alt="Vector1011"
                          className="frame-vector619"
                        />
                        <img
                          src="/external/vector1011-shw7.svg"
                          alt="Vector1011"
                          className="frame-vector620"
                        />
                        <img
                          src="/external/vector1011-jrz6e.svg"
                          alt="Vector1011"
                          className="frame-vector621"
                        />
                        <img
                          src="/external/vector1011-161.svg"
                          alt="Vector1011"
                          className="frame-vector622"
                        />
                        <img
                          src="/external/vector1011-csrh.svg"
                          alt="Vector1011"
                          className="frame-vector623"
                        />
                        <img
                          src="/external/vector1011-oulw.svg"
                          alt="Vector1011"
                          className="frame-vector624"
                        />
                        <img
                          src="/external/vector1011-zb3.svg"
                          alt="Vector1011"
                          className="frame-vector625"
                        />
                        <img
                          src="/external/vector1011-0d14.svg"
                          alt="Vector1011"
                          className="frame-vector626"
                        />
                        <img
                          src="/external/vector1011-ciwl.svg"
                          alt="Vector1011"
                          className="frame-vector627"
                        />
                        <img
                          src="/external/vector1011-xwv.svg"
                          alt="Vector1011"
                          className="frame-vector628"
                        />
                        <img
                          src="/external/vector1011-3l76.svg"
                          alt="Vector1011"
                          className="frame-vector629"
                        />
                        <img
                          src="/external/vector1011-t7y9.svg"
                          alt="Vector1011"
                          className="frame-vector630"
                        />
                        <img
                          src="/external/vector1011-u3yn.svg"
                          alt="Vector1011"
                          className="frame-vector631"
                        />
                        <img
                          src="/external/vector1011-48in.svg"
                          alt="Vector1011"
                          className="frame-vector632"
                        />
                        <img
                          src="/external/vector1011-vzvk.svg"
                          alt="Vector1011"
                          className="frame-vector633"
                        />
                        <img
                          src="/external/vector1011-132x.svg"
                          alt="Vector1011"
                          className="frame-vector634"
                        />
                        <img
                          src="/external/vector1011-ejg.svg"
                          alt="Vector1011"
                          className="frame-vector635"
                        />
                        <img
                          src="/external/vector1011-p8zt.svg"
                          alt="Vector1011"
                          className="frame-vector636"
                        />
                        <img
                          src="/external/vector1011-ipsr.svg"
                          alt="Vector1011"
                          className="frame-vector637"
                        />
                      </div>
                      <img
                        src="/external/vector1011-bmt.svg"
                        alt="Vector1011"
                        className="frame-vector638"
                      />
                      <img
                        src="/external/vector1011-ipco.svg"
                        alt="Vector1011"
                        className="frame-vector639"
                      />
                      <img
                        src="/external/vector1011-1rl.svg"
                        alt="Vector1011"
                        className="frame-vector640"
                      />
                      <img
                        src="/external/vector1011-c0w9.svg"
                        alt="Vector1011"
                        className="frame-vector641"
                      />
                      <img
                        src="/external/vector1011-218.svg"
                        alt="Vector1011"
                        className="frame-vector642"
                      />
                      <img
                        src="/external/vector1011-8yc.svg"
                        alt="Vector1011"
                        className="frame-vector643"
                      />
                      <img
                        src="/external/vector1011-1uin.svg"
                        alt="Vector1011"
                        className="frame-vector644"
                      />
                      <img
                        src="/external/vector1011-zoqg.svg"
                        alt="Vector1011"
                        className="frame-vector645"
                      />
                      <img
                        src="/external/vector1011-pjpm.svg"
                        alt="Vector1011"
                        className="frame-vector646"
                      />
                      <img
                        src="/external/vector1011-sxoc.svg"
                        alt="Vector1011"
                        className="frame-vector647"
                      />
                      <img
                        src="/external/vector1011-rxi.svg"
                        alt="Vector1011"
                        className="frame-vector648"
                      />
                      <img
                        src="/external/vector1011-yjyg.svg"
                        alt="Vector1011"
                        className="frame-vector649"
                      />
                      <img
                        src="/external/vector1011-qjm.svg"
                        alt="Vector1011"
                        className="frame-vector650"
                      />
                      <img
                        src="/external/vector1011-sg98.svg"
                        alt="Vector1011"
                        className="frame-vector651"
                      />
                    </div>
                  </div>
                </div>
                <div className="frame-group273">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector652"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector653"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector654"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector655"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector656"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector657"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector658"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector659"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector660"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector661"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector662"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector663"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector664"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector665"
                  />
                </div>
                <div className="frame-group274">
                  <div className="frame-group275">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector666"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector667"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector668"
                    />
                  </div>
                  <div className="frame-group276">
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector669"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector670"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="Vector1011"
                      className="frame-vector671"
                    />
                    <img
                      src="/external/vector1011-ucnk.svg"
                      alt="Vector1011"
                      className="frame-vector672"
                    />
                  </div>
                </div>
                <div className="frame-group277">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector673"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector674"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector675"
                  />
                </div>
                <div className="frame-group278">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector676"
                  />
                </div>
                <div className="frame-group279">
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector677"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector678"
                  />
                  <img
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    alt="Vector1011"
                    className="frame-vector679"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-frame62">
          <span className="frame-text209">
            <span>Send</span>
          </span>
        </div>
        <span className="frame-text211">
          <span>+7 (916) 822-32-42</span>
        </span>
        <span className="frame-text213">
          <span>info@im.work</span>
        </span>
        <img
          src="/external/solarphonebold1011-r6o.svg"
          alt="solarphonebold1011"
          className="frame-solarphonebold"
        />
        <img
          src="/external/icbaselineemail1011-5va.svg"
          alt="icbaselineemail1011"
          className="frame-icbaselineemail"
        />
        <img
          src="/external/rectangle1011-fmeh-600w.png"
          alt="Rectangle1011"
          className="frame-rectangle25"
        />
        <div className="frame-frame8822">
          <div className="frame-frame8820">
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Frame1011"
              className="frame-frame23"
            />
            <div className="frame-frame24">
              <div className="frame-group280">
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1011"
                  className="frame-vector680"
                />
                <img
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  alt="Vector1011"
                  className="frame-vector681"
                />
              </div>
            </div>
            <div className="frame-frame8821">
              <img
                src="/external/frame1011-o1uq.svg"
                alt="Frame1011"
                className="frame-frame25"
              />
            </div>
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Frame1011"
              className="frame-frame26"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Frame1011"
              className="frame-frame27"
            />
            <img
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              alt="Frame1011"
              className="frame-frame28"
            />
          </div>
        </div>
        <img
          src="/external/line121011-2jsv.svg"
          alt="Line121011"
          className="frame-line12"
        />
        <div className="frame-frame8823">
          <span className="frame-text215">
            <span>Solutions</span>
          </span>
          <span className="frame-text217">
            <span>For commercial organizations</span>
          </span>
          <span className="frame-text219">
            <span>State organizations</span>
          </span>
          <span className="frame-text221">
            <span>For remote work</span>
          </span>
        </div>
        <div className="frame-frame8824">
          <span className="frame-text223">
            <span>Departments</span>
          </span>
          <span className="frame-text225">
            <span>HR</span>
          </span>
          <span className="frame-text227">
            <span>Sales department</span>
          </span>
          <span className="frame-text229">
            <span>Marketing</span>
          </span>
          <span className="frame-text231">
            <span>Support</span>
          </span>
          <span className="frame-text233">
            <span>Project management</span>
          </span>
        </div>
        <div className="frame-frame8825">
          <span className="frame-text235">
            <span>Im&apos;work</span>
          </span>
          <span className="frame-text237">
            <span>Safety</span>
          </span>
          <span className="frame-text239">
            <span>Integrations</span>
          </span>
          <span className="frame-text241">
            <span>Prices</span>
          </span>
          <span className="frame-text243">
            <span>Download</span>
          </span>
          <span className="frame-text245">
            <span>About Us</span>
          </span>
          <span className="frame-text247">
            <span>Help Center</span>
          </span>
          <span className="frame-text249">
            <span>Certificates and licenses</span>
          </span>
          <span className="frame-text251">
            <span>Career</span>
          </span>
        </div>
        <div className="frame-frame8827">
          <img
            src="/external/frame1011-vo0cq.svg"
            alt="Frame1011"
            className="frame-frame29"
          />
          <span className="frame-text253">
            <span>Пользовательская документация</span>
          </span>
        </div>
        <div className="frame-frame8828">
          <img
            src="/external/frame1011-69a9.svg"
            alt="Frame1011"
            className="frame-frame30"
          />
          <span className="frame-text255">
            <span>Инструкция по установке</span>
          </span>
        </div>
        <span className="frame-text257">
          <span>© 2023 Im&apos;work</span>
        </span>
      </div>
    </div>
  )
}

export default Frame
